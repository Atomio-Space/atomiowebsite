import { motion } from 'framer-motion';
import type { Project } from '../data/projects';
import { format } from 'date-fns';
import classNames from 'classnames';

interface ProjectCardProps {
  project: Project;
  featured?: boolean;
  index: number;
}

export default function ProjectCard({ project, featured = false, index }: ProjectCardProps) {
  return (
    <motion.div 
      className={classNames(
        "group relative overflow-hidden rounded-lg",
        featured ? "col-span-2 row-span-2" : "col-span-1"
      )}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
    >
      <div className="aspect-w-16 aspect-h-9 w-full h-full bg-gray-100">
        <img 
          src={project.imageUrl} 
          alt={project.title} 
          className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-500"
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-0 left-0 p-6 w-full">
            <span className="text-xs text-white/80 font-medium tracking-wider">
              {format(new Date(project.date), 'MMM yyyy')} · {project.category}
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-white mt-2">{project.title}</h3>
            <p className="text-sm text-white/80 mt-1">{project.subtitle}</p>
            
            <div className="mt-4 flex items-center justify-between">
              <div className="text-xs text-white/70">{project.agency}, {project.location}</div>
              <button className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-xs text-white font-medium hover:bg-white/20">
                View Project
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {featured && (
        <div className="absolute top-4 left-4 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium text-white">
          Featured
        </div>
      )}
    </motion.div>
  );
}
