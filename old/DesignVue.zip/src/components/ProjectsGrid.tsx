import { useState } from 'react';
import { motion } from 'framer-motion';
import { projects, categories, getAllTags } from '../data/projects';
import ProjectCard from './ProjectCard';

export default function ProjectsGrid() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const allTags = getAllTags();
  
  const filteredProjects = projects.filter(project => {
    const categoryMatch = activeCategory === 'All' || project.category === activeCategory;
    const tagsMatch = activeTags.length === 0 || 
      activeTags.some(tag => project.tags.includes(tag));
    return categoryMatch && tagsMatch;
  });

  const toggleTag = (tag: string) => {
    setActiveTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag) 
        : [...prev, tag]
    );
  };

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 space-y-6 md:space-y-0">
          <h2 className="text-3xl font-bold tracking-tight">Discover Projects</h2>
          
          <div className="flex items-center space-x-1 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
            <button 
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === 'All' 
                  ? 'bg-black text-white' 
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('All')}
            >
              All
            </button>
            
            {categories.map(category => (
              <button 
                key={category}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  activeCategory === category 
                    ? 'bg-black text-white' 
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-8">
          {allTags.map(tag => (
            <button 
              key={tag}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                activeTags.includes(tag)
                  ? 'border-black bg-black text-white' 
                  : 'border-gray-300 text-gray-600 hover:border-gray-400'
              }`}
              onClick={() => toggleTag(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          layout
        >
          {filteredProjects.map((project, index) => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              featured={project.featured} 
              index={index}
            />
          ))}
        </motion.div>
        
        {filteredProjects.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">No projects found with the selected filters.</p>
            <button 
              className="mt-4 px-6 py-2 bg-gray-100 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors"
              onClick={() => {
                setActiveCategory('All');
                setActiveTags([]);
              }}
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
