import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-100 to-white opacity-70"></div>
        <div className="absolute top-0 left-0 w-1/3 h-1/3 bg-gradient-to-br from-pink-200 to-transparent rounded-full filter blur-3xl opacity-30 transform -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-1/2 h-1/2 bg-gradient-to-tl from-blue-200 to-transparent rounded-full filter blur-3xl opacity-20 transform translate-y-1/4"></div>
      </div>
      
      <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
        <motion.h1 
          className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight tracking-tighter mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Discover the finest in <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            design excellence
          </span>
        </motion.h1>
        
        <motion.p 
          className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Showcasing award-winning websites, digital experiences, and creative inspirations from around the world.
        </motion.p>
        
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <a 
            href="#" 
            className="px-8 py-3 bg-black text-white rounded-full font-medium hover:bg-gray-800 transition-colors"
          >
            Explore Projects
          </a>
          <a 
            href="#" 
            className="px-8 py-3 border border-gray-300 rounded-full font-medium hover:bg-gray-100 transition-colors"
          >
            Submit Your Work
          </a>
        </motion.div>
      </div>
      
      <div className="absolute bottom-10 left-0 right-0 flex justify-center">
        <motion.div 
          animate={{ y: [0, 10, 0] }} 
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <div className="w-6 h-10 border-2 border-gray-400 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-gray-400 rounded-full"></div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
