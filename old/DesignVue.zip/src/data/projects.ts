export interface Project {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  category: string;
  tags: string[];
  featured: boolean;
  date: string;
  agency: string;
  location: string;
  link: string;
}

export const projects: Project[] = [
  {
    id: '1',
    title: 'Monochrome Studio',
    subtitle: 'Digital art direction',
    imageUrl: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?q=80&w=1000&auto=format&fit=crop',
    category: 'Web Design',
    tags: ['Minimalist', 'Portfolio', 'Animation'],
    featured: true,
    date: '2024-04-15',
    agency: 'Black Square',
    location: 'Stockholm',
    link: '#'
  },
  {
    id: '2',
    title: 'Lumina',
    subtitle: 'Interactive experience',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop',
    category: 'Interactive',
    tags: ['Experimental', 'WebGL', 'Animation'],
    featured: true,
    date: '2024-03-22',
    agency: 'Bright Collective',
    location: 'Berlin',
    link: '#'
  },
  {
    id: '3',
    title: 'Concrete Perspective',
    subtitle: 'Architecture portfolio',
    imageUrl: 'https://images.unsplash.com/photo-1536329583941-14287ec6fc4e?q=80&w=1000&auto=format&fit=crop',
    category: 'Portfolio',
    tags: ['Brutalism', 'Architecture', 'Grid'],
    featured: true,
    date: '2024-02-18',
    agency: 'Structure Labs',
    location: 'Tokyo',
    link: '#'
  },
  {
    id: '4',
    title: 'Organica',
    subtitle: 'Brand identity system',
    imageUrl: 'https://images.unsplash.com/photo-1604871000636-074fa5117945?q=80&w=1000&auto=format&fit=crop',
    category: 'Branding',
    tags: ['Organic', 'Sustainable', 'Identity'],
    featured: false,
    date: '2024-01-10',
    agency: 'Green Studio',
    location: 'Copenhagen',
    link: '#'
  },
  {
    id: '5',
    title: 'Neon Dreams',
    subtitle: 'Digital experience',
    imageUrl: 'https://images.unsplash.com/photo-1494059980473-813e73ee784b?q=80&w=1000&auto=format&fit=crop',
    category: 'Interactive',
    tags: ['Neon', 'Dark UI', '3D'],
    featured: true,
    date: '2023-12-05',
    agency: 'Night Shift',
    location: 'Seoul',
    link: '#'
  },
  {
    id: '6',
    title: 'Geometry',
    subtitle: 'Digital art collection',
    imageUrl: 'https://images.unsplash.com/photo-1550859492-d5da9d8e45f3?q=80&w=1000&auto=format&fit=crop',
    category: 'Art',
    tags: ['Geometric', 'Abstract', 'Minimal'],
    featured: false,
    date: '2023-11-20',
    agency: 'Shape Works',
    location: 'Barcelona',
    link: '#'
  }
];

export const categories = Array.from(new Set(projects.map(project => project.category)));

export const getAllTags = () => {
  const allTags = projects.flatMap(project => project.tags);
  return Array.from(new Set(allTags));
};
